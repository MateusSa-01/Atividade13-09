import pytest
from django.urls import reverse
from django.test import Client
from core.models import Equipamento

@pytest.mark.django_db
def test_integracao_equipamento_criar_listar():
    client = Client()
    url_create = reverse('core:equipamentos_create')
    url_list = reverse('core:equipamentos_list')
    data = {"nome": "IntegracaoEquip", "codigo": "INTEQ01", "descricao": "Desc", "quantidade_total": 2}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"IntegracaoEquip" in response.content
