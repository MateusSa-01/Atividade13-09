import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador, Equipamento
from django.utils import timezone
from datetime import timedelta

@pytest.mark.django_db
def test_integracao_epi_criar_listar():
    colab = Colaborador.objects.create(nome="ColabEPI", matricula="COLABEPI01")
    equip = Equipamento.objects.create(nome="EquipEPI", codigo="EPIEQ01", descricao="Desc", quantidade_total=1)
    client = Client()
    url_create = reverse('core:epi_create')
    url_list = reverse('core:epi_list')
    data = {
        "colaborador": colab.id,
        "equipamento": equip.id,
        "data_entrega": timezone.now().strftime("%Y-%m-%dT%H:%M"),
        "data_prevista_devolucao": (timezone.now()+timedelta(days=2)).strftime("%Y-%m-%dT%H:%M"),
        "status": "EMPRESTADO",
        "observacao": "Teste integração",
        "observacao_devolucao": "",
    }
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"EquipEPI" in response.content
