import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador, Equipamento, EPIControle
from django.utils import timezone
from datetime import timedelta

@pytest.mark.django_db
def test_integracao_relatorios_filtro():
    colab = Colaborador.objects.create(nome="RelatorioIntegracao", matricula="RELINT01")
    equip = Equipamento.objects.create(nome="EquipRelatorio", codigo="EQREL01", descricao="Desc", quantidade_total=1)
    EPIControle.objects.create(colaborador=colab, equipamento=equip, data_prevista_devolucao=timezone.now()+timedelta(days=1))
    client = Client()
    url = reverse('core:relatorios')
    response = client.get(url, {"colaborador": "RelatorioIntegracao"})
    assert b"EquipRelatorio" in response.content
