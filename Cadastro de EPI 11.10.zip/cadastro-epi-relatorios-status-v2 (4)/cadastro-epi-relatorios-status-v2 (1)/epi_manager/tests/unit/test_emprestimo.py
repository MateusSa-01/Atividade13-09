import pytest
from core.models import Colaborador, Equipamento, EPIControle, EPIStatus
from django.utils import timezone
from datetime import timedelta

@pytest.mark.django_db
def test_criar_emprestimo():
    colaborador = Colaborador.objects.create(nome="Carlos", matricula="789")
    equipamento = Equipamento.objects.create(nome="Óculos", codigo="EPI003")
    data_prevista = timezone.now() + timedelta(days=7)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    assert emprestimo.status == EPIStatus.EMPRESTADO
    assert emprestimo.colaborador == colaborador

@pytest.mark.django_db
def test_str_emprestimo():
    colaborador = Colaborador.objects.create(nome="Ana", matricula="101")
    equipamento = Equipamento.objects.create(nome="Protetor", codigo="EPI004")
    data_prevista = timezone.now() + timedelta(days=5)
    emprestimo = EPIControle.objects.create(colaborador=colaborador, equipamento=equipamento, data_prevista_devolucao=data_prevista)
    assert str(emprestimo) == f"{equipamento} -> {colaborador} [{emprestimo.status}]"
