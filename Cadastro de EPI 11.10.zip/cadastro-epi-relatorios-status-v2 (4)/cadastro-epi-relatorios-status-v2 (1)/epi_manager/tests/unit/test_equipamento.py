import pytest
from core.models import Equipamento

@pytest.mark.django_db
def test_criar_equipamento():
    equipamento = Equipamento.objects.create(nome="Capacete", codigo="EPI001", descricao="Capacete de segurança", quantidade_total=10)
    assert equipamento.nome == "Capacete"
    assert equipamento.codigo == "EPI001"

@pytest.mark.django_db
def test_str_equipamento():
    equipamento = Equipamento.objects.create(nome="Luva", codigo="EPI002")
    assert str(equipamento) == "Luva (cód: EPI002)"
