import pytest
from django.test import Client
from django.urls import reverse
@pytest.mark.django_db
def test_integracao_colaborador_criar_listar():
    client = Client()
    url_create = reverse('core:colaboradores_create')
    url_list = reverse('core:colaboradores_list')
    data = {"nome": "IntegracaoColab", "matricula": "INTCOLAB01"}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"IntegracaoColab" in response.content

@pytest.mark.django_db
def test_integracao_equipamento_criar_listar():
    client = Client()
    url_create = reverse('core:equipamentos_create')
    url_list = reverse('core:equipamentos_list')
    data = {"nome": "IntegracaoEquip", "codigo": "INTEQ01", "descricao": "Desc", "quantidade_total": 2}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"IntegracaoEquip" in response.content

@pytest.mark.django_db
def test_integracao_epi_criar_listar():
    from core.models import Colaborador, Equipamento
    from django.utils import timezone
    from datetime import timedelta
    colab = Colaborador.objects.create(nome="ColabEPI", matricula="COLABEPI01")
    equip = Equipamento.objects.create(nome="EquipEPI", codigo="EPIEQ01", descricao="Desc", quantidade_total=1)
    client = Client()
    url_create = reverse('core:epi_create')
    url_list = reverse('core:epi_list')
    data = {
        "colaborador": colab.id,
        "equipamento": equip.id,
        "data_entrega": timezone.now().strftime("%Y-%m-%dT%H:%M"),
        "data_prevista_devolucao": (timezone.now()+timedelta(days=2)).strftime("%Y-%m-%dT%H:%M"),
        "status": "EMPRESTADO",
        "observacao": "Teste integração",
        "observacao_devolucao": "",
    }
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"EquipEPI" in response.content

@pytest.mark.django_db
def test_integracao_relatorios_filtro():
    from core.models import Colaborador, Equipamento, EPIControle
    from django.utils import timezone
    from datetime import timedelta
    colab = Colaborador.objects.create(nome="RelatorioIntegracao", matricula="RELINT01")
    equip = Equipamento.objects.create(nome="EquipRelatorio", codigo="EQREL01", descricao="Desc", quantidade_total=1)
    EPIControle.objects.create(colaborador=colab, equipamento=equip, data_prevista_devolucao=timezone.now()+timedelta(days=1))
    client = Client()
    url = reverse('core:relatorios')
    response = client.get(url, {"colaborador": "RelatorioIntegracao"})
    assert b"EquipRelatorio" in response.content
import pytest
from django.test import Client
from django.urls import reverse

@pytest.mark.django_db
def test_epi_list_view():
    from core.models import Colaborador, Equipamento, EPIControle
    colab = Colaborador.objects.create(nome="EPI User", matricula="EPI01")
    equip = Equipamento.objects.create(nome="Protetor", codigo="EPI10", descricao="Protetor", quantidade_total=2)
    from django.utils import timezone
    from datetime import timedelta
    EPIControle.objects.create(colaborador=colab, equipamento=equip, data_prevista_devolucao=timezone.now()+timedelta(days=2))
    client = Client()
    url = reverse('core:epi_list')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Protetor" in response.content

@pytest.mark.django_db
def test_epi_create_view():
    from core.models import Colaborador, Equipamento
    colab = Colaborador.objects.create(nome="EPI User2", matricula="EPI02")
    equip = Equipamento.objects.create(nome="Protetor2", codigo="EPI11", descricao="Protetor2", quantidade_total=2)
    client = Client()
    url = reverse('core:epi_create')
    from django.utils import timezone
    from datetime import timedelta
    data = {
        "colaborador": colab.id,
        "equipamento": equip.id,
        "data_prevista_devolucao": (timezone.now()+timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S"),
        "status": "EMPRESTADO"
    }
    response = client.post(url, data)
    assert response.status_code in [200, 302]  # 302 se sucesso, 200 se erro de validação

@pytest.mark.django_db
def test_relatorios_view():
    from core.models import Colaborador, Equipamento, EPIControle
    colab = Colaborador.objects.create(nome="Relatorio User", matricula="REL01")
    equip = Equipamento.objects.create(nome="Relatorio Equip", codigo="REL10", descricao="Relatorio", quantidade_total=1)
    from django.utils import timezone
    from datetime import timedelta
    EPIControle.objects.create(colaborador=colab, equipamento=equip, data_prevista_devolucao=timezone.now()+timedelta(days=1))
    client = Client()
    url = reverse('core:relatorios')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Relatorio" in response.content

@pytest.mark.django_db
def test_relatorios_view_filtro_colaborador():
    from core.models import Colaborador, Equipamento, EPIControle
    colab = Colaborador.objects.create(nome="Filtro User", matricula="FIL01")
    equip = Equipamento.objects.create(nome="Filtro Equip", codigo="FIL10", descricao="Filtro", quantidade_total=1)
    from django.utils import timezone
    from datetime import timedelta
    EPIControle.objects.create(colaborador=colab, equipamento=equip, data_prevista_devolucao=timezone.now()+timedelta(days=1))
    client = Client()
    url = reverse('core:relatorios')
    response = client.get(url, {"colaborador": "Filtro User"})
    assert response.status_code == 200
    assert b"Filtro" in response.content
import pytest
from django.urls import reverse
from django.test import Client
from core.models import Colaborador, Equipamento

@pytest.mark.django_db
def test_colaboradores_list_view():
    Colaborador.objects.create(nome="Teste", matricula="001")
    client = Client()
    url = reverse('core:colaboradores_list')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Teste" in response.content

@pytest.mark.django_db
def test_equipamentos_list_view():
    Equipamento.objects.create(nome="Capacete", codigo="E001")
    client = Client()
    url = reverse('core:equipamentos_list')
    response = client.get(url)
    assert response.status_code == 200
    assert b"Capacete" in response.content

@pytest.mark.django_db
def test_colaboradores_create_view():
    client = Client()
    url = reverse('core:colaboradores_create')
    data = {"nome": "Novo", "matricula": "999"}
    response = client.post(url, data)
    assert response.status_code == 302  # redirect após sucesso
    assert Colaborador.objects.filter(matricula="999").exists()

@pytest.mark.django_db
def test_equipamentos_create_view():
    client = Client()
    url = reverse('core:equipamentos_create')
    data = {
        "nome": "Luva",
        "codigo": "E002",
        "descricao": "Luva de proteção",
        "quantidade_total": 5
    }
    response = client.post(url, data)
    assert response.status_code == 302
    assert Equipamento.objects.filter(codigo="E002").exists()

@pytest.mark.django_db
def test_integracao_criar_listar_colaborador():
    client = Client()
    url_create = reverse('core:colaboradores_create')
    url_list = reverse('core:colaboradores_list')
    data = {"nome": "Integracao", "matricula": "888"}
    client.post(url_create, data)
    response = client.get(url_list)
    assert b"Integracao" in response.content
